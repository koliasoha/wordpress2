<!DOCTYPE html>
<html>
<body>

<div class = "navbar navbar-default navbar-fixed-bottom">

    <div class = "container">
        <p class = "navbar-text pull-left">Site Built By Ahsan</p>
        <a href = "http://youtube.com/" class = "navbar-btn btn-danger btn pull-right">Subscribe on YouTube</a>
    </div>

</div>
<?php wp_footer(); ?>

<div class = "modal fade" id = "contact" role = "dialog">
    <div class = "modal-dialog">
        <div class = "modal-content">
            <form class = "form-horizontal">
                <div class = "modal-header">
                    <h4>Contact BootStrap Theme</h4>
                </div>
                <div class = "modal-body">

                    <div class = "form-group">

                        <label for = "contact-name" class = "col-lg-2 control-label">Name:</label>
                        <div class = "col-lg-10">

                            <input type = "text" class = "form-control" id = "contact-name" placeholder = "Full Name">

                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../wp-content/themes/MyBSTheme/js/bootstrap.min.js"></script>

</body>
</html>

